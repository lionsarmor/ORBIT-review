// Local-only companion: no DevTools or host filesystem access is exposed to peers.
import http from 'node:http';
import {randomBytes,timingSafeEqual} from 'node:crypto';
import {mkdir,writeFile} from 'node:fs/promises';
import {homedir} from 'node:os';
import {join} from 'node:path';
import {WebSocketServer} from 'ws';
import {chromium} from 'playwright';
import {address,pinned,publicProxy} from './network.js';
const port=Number(process.env.ORBIT_BROWSER_PORT||8770),testOrigin=process.env.NODE_ENV==='test'?process.env.ORBIT_BROWSER_TEST_ORIGIN:undefined;
const origins=new Set(['https://orbit.143-244-168-180.sslip.io','https://lionsarmor.github.io','http://127.0.0.1:8765','http://localhost:8765']);
const token=randomBytes(32).toString('base64url'),grants=new Map(),confirmations=new Map(),clients=new Set();
const equal=(a,b)=>typeof a==='string'&&/^[-\w]{43}$/.test(a)&&a.length===b.length&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const server=http.createServer(async(req,res)=>{
 if(![`127.0.0.1:${port}`,`localhost:${port}`].includes(req.headers.host)){res.writeHead(403);res.end();return;}
 res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Content-Security-Policy',"default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'");
 let url;try{url=new URL(req.url,'http://127.0.0.1');}catch{res.writeHead(400);res.end();return;}
 if(req.method==='GET'&&url.pathname==='/health'){res.end('ORBIT peer browser ready');return;}
 if(req.method==='GET'&&url.pathname==='/pair'){
  const origin=url.searchParams.get('origin'),nonce=url.searchParams.get('nonce');
  if(!origins.has(origin)||!/^[-\w]{24,80}$/.test(nonce||'')){res.writeHead(403);res.end('Open hosting from ORBIT.');return;}
  const csrf=randomBytes(32).toString('base64url');if(confirmations.size>=128)confirmations.delete(confirmations.keys().next().value);confirmations.set(csrf,{origin,nonce,expires:Date.now()+120000});
  res.setHeader('Content-Type','text/html; charset=utf-8');res.end(`<!doctype html><meta name="viewport" content="width=device-width"><title>ORBIT · Host a Web event</title><style>body{background:#19140f;color:#eddab7;font:18px system-ui;max-width:560px;margin:12vh auto;padding:30px}h1{font-weight:400}button{background:linear-gradient(115deg,#bd8b44,#ffe4a5,#a57637);padding:16px 24px;border:1px solid #e8c77d;border-radius:10px;color:#26180b;font:inherit;cursor:pointer}p{line-height:1.6}small{color:#b8a68a}</style><h1>Your computer. Our little window.</h1><p>Enable hosting for <strong>${escape(origin)}</strong>?</p><p>ORBIT opens a fresh, temporary browser. People in your Web event can see and control that browser, including anything you type into it. Your personal browser and files stay separate.</p><p>Only public websites are reachable. Downloads, camera, microphone and private-network pages are blocked. Web-event audio is not streamed.</p><form method="post" action="/pair"><input type="hidden" name="csrf" value="${csrf}"><button>Enable peer hosting ↗</button></form><p><small>This permission lasts until the companion restarts.</small></p>`);return;
 }
 if(req.method==='POST'&&url.pathname==='/pair'&&req.headers.origin===`http://127.0.0.1:${port}`){
  let body='';for await(const chunk of req){body+=chunk;if(body.length>512){res.writeHead(413);res.end();return;}}
  const csrf=new URLSearchParams(body).get('csrf'),grant=confirmations.get(csrf);confirmations.delete(csrf);
  if(!grant||grant.expires<Date.now()){res.writeHead(403);res.end('Open hosting again in ORBIT.');return;}
  const access=randomBytes(32).toString('base64url');if(grants.size>=128)grants.delete(grants.keys().next().value);grants.set(access,grant.origin);
  res.setHeader('Content-Type','text/html; charset=utf-8');res.end(`<title>ORBIT hosting enabled</title><p>Hosting enabled. Return to ORBIT.</p><script>if(opener){opener.postMessage(${JSON.stringify({type:'orbit-host-paired',nonce:grant.nonce,token:access})},${JSON.stringify(grant.origin)});window.close();}</script>`);return;
 }
 res.writeHead(404);res.end();
});
const wss=new WebSocketServer({noServer:true,maxPayload:65536});
server.on('upgrade',(req,socket,head)=>{if(!origins.has(req.headers.origin)||req.url!=='/browser'||![`127.0.0.1:${port}`,`localhost:${port}`].includes(req.headers.host)||clients.size>=8){socket.destroy();return;}wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));});
let browserCount=0;
wss.on('connection',(ws,req)=>{
 clients.add(ws);let authenticated=false,lastSeen=Date.now(),browser,context,page,cdp,proxy,ended=false,queued=0,chain=Promise.resolve(),viewURL='',lastFrame=0,slot=false;
 const send=value=>{if(ws.readyState===1)ws.send(JSON.stringify(value));};
 const cleanup=async()=>{if(ended)return;ended=true;clearInterval(timer);clients.delete(ws);await browser?.close().catch(()=>{});proxy?.close();if(slot){browserCount--;slot=false;}};
 const timer=setInterval(()=>{if(Date.now()-lastSeen>30000){ws.close();cleanup();}},5000);
 ws.on('close',cleanup);ws.on('error',cleanup);
 const validate=async value=>{const u=address(value,testOrigin);await pinned(u.hostname,u.port||(u.protocol==='https:'?443:80),testOrigin);return u.href;};
 async function start(url){
  if(slot||browserCount>=4)throw Error('Up to four hosted Web events at a time.');
  url=await validate(url);if(browserCount>=4)throw Error('Up to four hosted Web events at a time.');browserCount++;slot=true;proxy=await publicProxy({testOrigin});
  browser=await chromium.launch({headless:true,chromiumSandbox:true,proxy:proxy.settings,args:['--proxy-bypass-list=<-loopback>','--disable-quic','--force-webrtc-ip-handling-policy=disable_non_proxied_udp']});
  if(ended){await browser.close();if(slot){browserCount--;slot=false;}browser=null;return;}
  browser.on('disconnected',()=>{if(!ended){send({type:'ended',message:'The host browser closed.'});ws.close();}});
  context=await browser.newContext({viewport:{width:1280,height:800},acceptDownloads:false,serviceWorkers:'block',permissions:[]});
  await context.route('**/*',async route=>{try{const u=new URL(route.request().url());if(!['http:','https:'].includes(u.protocol))throw Error();await validate(u.href);await route.continue();}catch{await route.abort('blockedbyclient');}});
  page=await context.newPage();context.on('page',p=>{if(p!==page)p.close().catch(()=>{});});
  page.on('download',d=>d.cancel().catch(()=>{}));page.on('dialog',d=>d.dismiss().catch(()=>{}));
  page.on('framenavigated',frame=>{if(frame===page.mainFrame()&&/^https?:/.test(frame.url())){viewURL=frame.url();send({type:'location',url:viewURL});}});
  cdp=await context.newCDPSession(page);
  cdp.on('Page.screencastFrame',async frame=>{cdp.send('Page.screencastFrameAck',{sessionId:frame.sessionId}).catch(()=>{});if(Date.now()-lastFrame<90||ws.bufferedAmount>600000)return;lastFrame=Date.now();send({type:'frame',data:frame.data});});
  await cdp.send('Page.startScreencast',{format:'jpeg',quality:75,maxWidth:1280,maxHeight:800,everyNthFrame:1});
  send({type:'started',width:1280,height:800});await page.goto(url,{waitUntil:'domcontentloaded',timeout:25000}).catch(()=>send({type:'notice',message:'This website could not finish loading. Try another public address.'}));
 }
 async function input(a){
  if(!page||!a||typeof a!=='object')return;
  const xy=p=>{if(!Number.isFinite(p.x)||!Number.isFinite(p.y))throw Error('Invalid pointer');return [Math.max(0,Math.min(1279,p.x)),Math.max(0,Math.min(799,p.y))];};
  switch(a.type){
   case 'navigate':await page.goto(await validate(a.url),{waitUntil:'domcontentloaded',timeout:25000});break;
   case 'reload':await page.reload({waitUntil:'domcontentloaded',timeout:25000});break;
   case 'back':await page.goBack({waitUntil:'domcontentloaded',timeout:25000});break;
   case 'click':await page.mouse.click(...xy(a),{button:a.button==='right'?'right':'left',clickCount:a.double?2:1});break;
   case 'scroll':await page.mouse.move(...xy(a));await page.mouse.wheel(Math.max(-1600,Math.min(1600,Number(a.dx)||0)),Math.max(-1600,Math.min(1600,Number(a.dy)||0)));break;
   case 'drag':if(!Array.isArray(a.points)||a.points.length<2||a.points.length>80)break;await page.mouse.move(...xy(a.points[0]));await page.mouse.down();try{for(const p of a.points.slice(1))await page.mouse.move(...xy(p));}finally{await page.mouse.up();}break;
   case 'text':if(typeof a.text==='string'&&a.text.length<=2000)await page.keyboard.insertText(a.text);break;
   case 'key':if(typeof a.key==='string'&&/^(?:(?:Control|Alt|Shift|Meta)\+){0,3}(?:[a-zA-Z0-9]|Enter|Tab|Backspace|Delete|Escape|ArrowUp|ArrowDown|ArrowLeft|ArrowRight|Home|End|PageUp|PageDown|Space)$/.test(a.key))await page.keyboard.press(a.key);break;
  }
 }
 ws.on('message',raw=>{
  let msg;try{msg=JSON.parse(raw);}catch{ws.close();return;}if(!msg||typeof msg!=='object'||Array.isArray(msg)){ws.close();return;}
  if(!authenticated){if(msg.type!=='auth'||!(equal(msg.token,token)||grants.get(msg.token)===req.headers.origin)){ws.close();return;}authenticated=true;send({type:'ready'});return;}
  lastSeen=Date.now();if(msg.type==='ping'){send({type:'pong'});return;}if(msg.type==='stop'){ws.close();cleanup();return;}
  if(!['start','input'].includes(msg.type)||queued>=40){send({type:'notice',message:'The browser is catching up. Try again in a moment.'});return;}
  queued++;chain=chain.then(async()=>{if(ended)return;if(msg.type==='start')await start(msg.url);else await input(msg.action);}).catch(e=>{send({type:'notice',message:e.message?.includes('Private')||e.message?.includes('Use a public')?e.message:'That browser action could not finish.'});if(msg.type==='start'){ws.close();cleanup();}}).finally(()=>queued--);
 });
 setTimeout(()=>{if(!authenticated)ws.close();},5000).unref();
});
await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
const runtime=process.env.ORBIT_BROWSER_RUNTIME||join(homedir(),'.cache/orbit');await mkdir(runtime,{recursive:true,mode:0o700});await writeFile(join(runtime,'peer-browser.json'),JSON.stringify({port,token}),{mode:0o600});
console.log(`ORBIT peer browser ready on 127.0.0.1:${port}`);
const expiry=setInterval(()=>{for(const [key,value]of confirmations)if(value.expires<Date.now())confirmations.delete(key);},60000);expiry.unref();
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{for(const ws of clients)ws.close();server.close();setTimeout(()=>process.exit(0),1500).unref();});
