// A public-web-only forward proxy. DNS answers are checked and pinned per socket.
import http from 'node:http';
import net from 'node:net';
import {lookup} from 'node:dns/promises';
import {randomBytes} from 'node:crypto';
import ipaddr from 'ipaddr.js';
export function publicIP(value){try{return ipaddr.process(value).range()==='unicast';}catch{return false;}}
export function address(value,testOrigin){const u=new URL(value);if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.href.length>4096||u.port&&u.port!==(u.protocol==='https:'?'443':'80')&&u.origin!==testOrigin)throw Error('Use a public http or https webpage on its standard port.');return u;}
export async function pinned(host,port,testOrigin){
 const name=host.replace(/^\[|\]$/g,'');
 const results=net.isIP(name)?[{address:name,family:net.isIP(name)}]:await lookup(name,{all:true});
 const test=testOrigin&&new URL(testOrigin);
 const permittedTest=test&&test.hostname===name&&Number(test.port||80)===Number(port);
 if(!results.length||(!permittedTest&&results.some(a=>!publicIP(a.address))))throw Error('Private and local network pages are not available to the shared browser.');
 return results[0];
}
export async function publicProxy({testOrigin}={}){
 const password=randomBytes(24).toString('hex'),authorization='Basic '+Buffer.from('orbit:'+password).toString('base64'),sockets=new Set();
 const authorize=req=>req.headers['proxy-authorization']===authorization;
 const server=http.createServer(async(req,res)=>{
  if(!authorize(req)){res.writeHead(407,{'Proxy-Authenticate':'Basic realm="ORBIT"'});res.end();return;}
  try{
   const u=address(req.url,testOrigin);if(u.protocol!=='http:')throw Error('Invalid proxy request');
   const ip=await pinned(u.hostname,u.port||80,testOrigin),headers={...req.headers,host:u.host};delete headers['proxy-authorization'];delete headers['proxy-connection'];
   const upstream=http.request({hostname:ip.address,family:ip.family,port:Number(u.port)||80,path:u.pathname+u.search,method:req.method,headers,timeout:15000},r=>{res.writeHead(r.statusCode,r.headers);r.pipe(res);});
   upstream.on('timeout',()=>upstream.destroy());upstream.on('error',()=>{if(!res.headersSent)res.writeHead(502);res.end();});req.on('aborted',()=>upstream.destroy());req.pipe(upstream);
  }catch{res.writeHead(403);res.end('This address is outside the shared public web.');}
 });
 server.on('connect',async(req,client,head)=>{
  if(!authorize(req)){client.end('HTTP/1.1 407 Proxy Authentication Required\r\nProxy-Authenticate: Basic realm="ORBIT"\r\n\r\n');return;}
  try{
   const u=address('https://'+req.url,testOrigin),ip=await pinned(u.hostname,u.port||443,testOrigin);
   const upstream=net.connect({host:ip.address,family:ip.family,port:Number(u.port)||443});sockets.add(upstream);upstream.on('close',()=>sockets.delete(upstream));
   upstream.setTimeout(120000,()=>upstream.destroy());upstream.on('connect',()=>{client.write('HTTP/1.1 200 Connection Established\r\n\r\n');if(head.length)upstream.write(head);client.pipe(upstream);upstream.pipe(client);});upstream.on('error',()=>client.destroy());client.on('error',()=>upstream.destroy());client.on('close',()=>upstream.destroy());
  }catch{client.end('HTTP/1.1 403 Forbidden\r\n\r\n');}
 });
 server.on('connection',s=>{sockets.add(s);s.on('close',()=>sockets.delete(s));s.on('error',()=>{});});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 return {settings:{server:`http://127.0.0.1:${server.address().port}`,username:'orbit',password},close:()=>{for(const s of sockets)s.destroy();server.close();}};
}
